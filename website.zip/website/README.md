
All of the files in this folder are the files necessary to run our interactive web-based tool locally.

To run this website, you must start a local web server from this directory. For example, this can be done in Python 3 by running the following command:

```
python -m http.server 4000
```

Then, point a modern web browser (Chrome, Firefox, Safari) to `http://localhost:4000/` or whatever port was used by the local web server.

These files are provided so you can run the website locally on your own system. For the latest version of our tool and website, please visit:

http://vgl.cs.usfca.edu/animated-sploms/index.html
